# Android manifest & permission hardening

Run `npx cap add android` first (needs network + Android SDK — do this on
your machine, not in this sandbox). Then apply these changes to
`android/app/src/main/AndroidManifest.xml` before building.

## 1. Disable auto-backup of the raw database

By default Android's Auto Backup can copy your app's SQLite files (even the
SQLCipher-encrypted one, plus its journal/WAL files, and — more importantly —
any *unencrypted* temp files created during import/export) to the user's
Google account. Turn this off entirely:

```xml
<application
    android:allowBackup="false"
    android:fullBackupContent="false"
    ...>
```

If you later want a *deliberate*, encrypted backup path for directors, build
that as an explicit "Export encrypted backup" action in-app (reusing the
audit-logged export flow already in `src/lib/export.ts`), not via Android's
implicit backup system.

## 2. Trim permissions to exactly what's used

The Camera and Filesystem Capacitor plugins request permissions in the
manifest automatically when you run `npx cap sync`. Audit the generated
manifest and confirm you only have:

```xml
<uses-permission android:name="android.permission.CAMERA" />
```

You should **not** see `READ_EXTERNAL_STORAGE`, `WRITE_EXTERNAL_STORAGE`, or
`MANAGE_EXTERNAL_STORAGE`. The app writes exports to `Directory.Data` (private
app storage, see `src/lib/export.ts`), which needs no storage permission on
API 29+. If a plugin pulls in a broad storage permission you don't need,
remove it in the manifest and confirm the app still builds/runs — Capacitor
merges plugin manifests but an explicit `tools:node="remove"` override works:

```xml
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" tools:node="remove" />
```
(requires `xmlns:tools="http://schemas.android.com/tools"` on `<manifest>`)

## 3. Prevent screenshots / recent-apps thumbnail leakage

A recent-apps switcher thumbnail of a student list is itself a data leak on
a shared device. Add to your main Activity's `onCreate` (in
`MainActivity.java` / `.kt`):

```java
getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
```

This also blocks screenshots and screen recording while the app is open.

## 4. Network security config

Even though this build is local-first with no backend, ship a network
security config that blocks cleartext traffic outright, so a future plugin
or dependency can't silently phone home over HTTP:

`android/app/src/main/res/xml/network_security_config.xml`:
```xml
<network-security-config>
    <base-config cleartextTrafficPermitted="false" />
</network-security-config>
```

Reference it in the manifest:
```xml
<application android:networkSecurityConfig="@xml/network_security_config" ...>
```

## 5. Minimum SDK / target SDK

Keep `minSdkVersion` and `targetSdkVersion` current in
`android/variables.gradle` — Google Play requires targeting a recent API
level, and newer API levels default several of the above protections on.
