import { v4 as uuid } from 'uuid';
import { getDb } from './database';
import { logAudit } from './audit';
import type { AuthUser } from '../context/AuthContext';

export interface Contact {
  name: string;
  relation: string;
  phone: string;
  email?: string;
}

export interface Student {
  id: string;
  first_name: string;
  last_name: string;
  dob: string;
  class_grade: string;
  enrollment_year?: string;
  photo_path?: string;
  guardian_contacts: Contact[];
  emergency_contacts: Contact[];
  medical_notes?: string;
  status: 'active' | 'archived';
  created_at: string;
  updated_at: string;
  created_by: string;
  updated_by: string;
  archived_at?: string;
  archived_by?: string;
  archive_reason?: string;
}

type StudentInput = Omit<
  Student,
  'id' | 'status' | 'created_at' | 'updated_at' | 'created_by' | 'updated_by' | 'archived_at' | 'archived_by' | 'archive_reason'
>;

function rowToStudent(row: any): Student {
  return {
    ...row,
    guardian_contacts: row.guardian_contacts ? JSON.parse(row.guardian_contacts) : [],
    emergency_contacts: row.emergency_contacts ? JSON.parse(row.emergency_contacts) : [],
  };
}

/** Role scoping: teachers only ever see students in their assigned class. */
function scopeClause(actor: AuthUser): { clause: string; params: any[] } {
  if (actor.role === 'director') return { clause: '', params: [] };
  return { clause: 'AND class_grade = ?', params: [actor.assigned_class] };
}

export async function listStudents(
  actor: AuthUser,
  opts: { search?: string; classGrade?: string; includeArchived?: boolean } = {}
): Promise<Student[]> {
  const db = getDb();
  const { clause, params } = scopeClause(actor);
  const conditions: string[] = [];
  const args: any[] = [];

  if (!opts.includeArchived) conditions.push("status = 'active'");
  if (opts.search) {
    conditions.push('(first_name LIKE ? OR last_name LIKE ?)');
    args.push(`%${opts.search}%`, `%${opts.search}%`);
  }
  if (opts.classGrade) {
    conditions.push('class_grade = ?');
    args.push(opts.classGrade);
  }

  const where = conditions.length ? `WHERE ${conditions.join(' AND ')} ${clause}` : clause ? `WHERE 1=1 ${clause}` : '';
  const res = await db.query(
    `SELECT * FROM students ${where} ORDER BY last_name, first_name`,
    [...args, ...params]
  );
  return (res.values ?? []).map(rowToStudent);
}

export async function getStudent(actor: AuthUser, id: string): Promise<Student | null> {
  const db = getDb();
  const { clause, params } = scopeClause(actor);
  const res = await db.query(`SELECT * FROM students WHERE id = ? ${clause}`, [id, ...params]);
  const row = res.values?.[0];
  if (!row) return null;
  await logAudit(actor, 'view', 'student', id, `${row.first_name} ${row.last_name}`);
  return rowToStudent(row);
}

export async function createStudent(actor: AuthUser, input: StudentInput): Promise<Student> {
  const db = getDb();
  const now = new Date().toISOString();
  const id = uuid();
  await db.run(
    `INSERT INTO students
      (id, first_name, last_name, dob, class_grade, enrollment_year, photo_path,
       guardian_contacts, emergency_contacts, medical_notes, status,
       created_at, updated_at, created_by, updated_by)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?, ?, ?)`,
    [
      id,
      input.first_name,
      input.last_name,
      input.dob,
      input.class_grade,
      input.enrollment_year ?? null,
      input.photo_path ?? null,
      JSON.stringify(input.guardian_contacts ?? []),
      JSON.stringify(input.emergency_contacts ?? []),
      input.medical_notes ?? null,
      now,
      now,
      actor.id,
      actor.id,
    ]
  );
  await logAudit(actor, 'create', 'student', id, `${input.first_name} ${input.last_name}`);
  return (await getStudentRaw(id))!;
}

async function getStudentRaw(id: string): Promise<Student | null> {
  const db = getDb();
  const res = await db.query('SELECT * FROM students WHERE id = ?', [id]);
  const row = res.values?.[0];
  return row ? rowToStudent(row) : null;
}

export async function updateStudent(actor: AuthUser, id: string, input: Partial<StudentInput>): Promise<void> {
  const db = getDb();
  const existing = await getStudentRaw(id);
  if (!existing) throw new Error('Record not found');
  if (actor.role === 'teacher' && existing.class_grade !== actor.assigned_class) {
    throw new Error('Not authorized to edit a student outside your class');
  }

  const merged = { ...existing, ...input };
  await db.run(
    `UPDATE students SET
      first_name = ?, last_name = ?, dob = ?, class_grade = ?, enrollment_year = ?,
      photo_path = ?, guardian_contacts = ?, emergency_contacts = ?, medical_notes = ?,
      updated_at = ?, updated_by = ?
     WHERE id = ?`,
    [
      merged.first_name,
      merged.last_name,
      merged.dob,
      merged.class_grade,
      merged.enrollment_year ?? null,
      merged.photo_path ?? null,
      JSON.stringify(merged.guardian_contacts ?? []),
      JSON.stringify(merged.emergency_contacts ?? []),
      merged.medical_notes ?? null,
      new Date().toISOString(),
      actor.id,
      id,
    ]
  );
  await logAudit(actor, 'update', 'student', id, `${merged.first_name} ${merged.last_name}`);
}

/** Soft-delete only. Hard deletion is a separate, director-only, doubly-logged retention action. */
export async function archiveStudent(actor: AuthUser, id: string, reason: string): Promise<void> {
  const db = getDb();
  const now = new Date().toISOString();
  await db.run(
    `UPDATE students SET status = 'archived', archived_at = ?, archived_by = ?, archive_reason = ? WHERE id = ?`,
    [now, actor.id, reason, id]
  );
  await logAudit(actor, 'archive', 'student', id, reason);
}

export async function restoreStudent(actor: AuthUser, id: string): Promise<void> {
  if (actor.role !== 'director') throw new Error('Only a director can restore an archived record');
  const db = getDb();
  await db.run(
    `UPDATE students SET status = 'active', archived_at = NULL, archived_by = NULL, archive_reason = NULL WHERE id = ?`,
    [id]
  );
  await logAudit(actor, 'restore', 'student', id, null);
}
