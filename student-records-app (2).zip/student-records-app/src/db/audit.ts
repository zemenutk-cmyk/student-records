import { v4 as uuid } from 'uuid';
import { getDb } from './database';
import type { AuthUser } from '../context/AuthContext';

export type AuditAction =
  | 'login'
  | 'login_fail'
  | 'logout'
  | 'session_timeout'
  | 'view'
  | 'create'
  | 'update'
  | 'archive'
  | 'restore'
  | 'export';

/**
 * Every read or write to a student record goes through this. Audit rows are
 * append-only from the app's perspective — there is no UI path that updates
 * or deletes an audit_log row. This is what makes "who viewed/edited which
 * record and when" answerable for a safeguarding review.
 */
export async function logAudit(
  actor: AuthUser,
  action: AuditAction,
  entityType: 'student' | 'user' | null,
  entityId: string | null,
  detail: string | null
): Promise<void> {
  const db = getDb();
  await db.run(
    `INSERT INTO audit_log (id, user_id, username, action, entity_type, entity_id, detail, timestamp)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [uuid(), actor.id, actor.username, action, entityType, entityId, detail, new Date().toISOString()]
  );
}

export interface AuditRow {
  id: string;
  user_id: string;
  username: string;
  action: AuditAction;
  entity_type: string | null;
  entity_id: string | null;
  detail: string | null;
  timestamp: string;
}

/** Director-only view — enforced at the call site (see pages/AuditLog.tsx) as well as here. */
export async function listAuditLog(actor: AuthUser, opts: { entityId?: string; limit?: number } = {}): Promise<AuditRow[]> {
  if (actor.role !== 'director') throw new Error('Only a director can view the audit log');
  const db = getDb();
  const conditions: string[] = [];
  const args: any[] = [];
  if (opts.entityId) {
    conditions.push('entity_id = ?');
    args.push(opts.entityId);
  }
  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  const res = await db.query(
    `SELECT * FROM audit_log ${where} ORDER BY timestamp DESC LIMIT ?`,
    [...args, opts.limit ?? 500]
  );
  return res.values ?? [];
}
