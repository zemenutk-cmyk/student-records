import { Preferences } from '@capacitor/preferences';

/**
 * ⚠️ REPLACE BEFORE PRODUCTION USE ⚠️
 *
 * This placeholder stores the SQLCipher passphrase with @capacitor/preferences,
 * which on Android is plain SharedPreferences — NOT encrypted, and readable by
 * anyone with root/ADB access to the device or a full backup. It is here only
 * so the app runs end-to-end in development.
 *
 * Before shipping to a school device, swap this implementation for one backed
 * by the Android Keystore, e.g.:
 *
 *   npm install capacitor-secure-storage-plugin
 *
 * and use its EncryptedSharedPreferences-backed get/set instead of
 * @capacitor/preferences. That plugin generates and stores the AES key inside
 * the hardware-backed Keystore, so the passphrase itself is never written to
 * disk in recoverable form.
 *
 * Do not log this value, include it in crash reports, or send it anywhere.
 */

const KEY = 'db_passphrase_DO_NOT_USE_PREFS_IN_PROD';

function randomPassphrase(): string {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('');
}

export async function getOrCreateDbPassphrase(): Promise<string> {
  const existing = await Preferences.get({ key: KEY });
  if (existing.value) return existing.value;
  const generated = randomPassphrase();
  await Preferences.set({ key: KEY, value: generated });
  return generated;
}
