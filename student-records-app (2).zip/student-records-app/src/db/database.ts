import { CapacitorSQLite, SQLiteConnection, SQLiteDBConnection } from '@capacitor-community/sqlite';
import { Capacitor } from '@capacitor/core';

const DB_NAME = 'student_records';

const sqlite = new SQLiteConnection(CapacitorSQLite);
let db: SQLiteDBConnection | null = null;

/**
 * Where the encryption passphrase comes from.
 *
 * DO NOT hardcode a secret here and do not store it in @capacitor/preferences
 * (that is unencrypted shared-prefs / plist, readable on a rooted or
 * unlocked device). For a real deployment, back this with the Android
 * Keystore, e.g. via `capacitor-secure-storage-plugin` (which wraps
 * EncryptedSharedPreferences / Keystore on Android) or a small native
 * plugin. This function is the single place that needs replacing —
 * everything else in the app just calls getOrCreatePassphrase().
 */
async function getOrCreatePassphrase(): Promise<string> {
  const mod = await import('./secureSecret');
  return mod.getOrCreateDbPassphrase();
}

export async function initDatabase(): Promise<SQLiteDBConnection> {
  if (db) return db;

  if (Capacitor.getPlatform() === 'web') {
    // jeep-sqlite web fallback for local dev in the browser only.
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const jeepSqlite = document.createElement('jeep-sqlite');
    document.body.appendChild(jeepSqlite);
    await customElements.whenDefined('jeep-sqlite');
    await sqlite.initWebStore();
  }

  const passphrase = await getOrCreatePassphrase();

  const isConn = (await sqlite.isConnection(DB_NAME, false)).result;
  db = isConn
    ? await sqlite.retrieveConnection(DB_NAME, false)
    : await sqlite.createConnection(DB_NAME, true, 'encryption', 1, false);

  await db.open();
  // Sets/validates the SQLCipher key for this connection. If the DB was
  // just created, this establishes the key; on subsequent opens it must
  // match or every query will fail — which is the point.
  await db.execute(`PRAGMA key = '${passphrase.replace(/'/g, "''")}';`);

  await runMigrations(db);
  return db;
}

async function runMigrations(conn: SQLiteDBConnection) {
  await conn.execute(SCHEMA);
}

export function getDb(): SQLiteDBConnection {
  if (!db) throw new Error('Database not initialized — call initDatabase() first');
  return db;
}

// ---------------------------------------------------------------------------
// Schema
//
// Notes on data minimisation: only fields explicitly requested are stored.
// `medical_notes` and contact fields are free text/JSON kept in the same
// encrypted DB as everything else — there is no separate unencrypted store.
// `deleted_at` implements soft-delete for the audit trail; nothing is ever
// hard-deleted from student_records except via the explicit purge tool
// described in the retention policy doc, which is a separate, logged action.
// ---------------------------------------------------------------------------
const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  full_name TEXT NOT NULL,
  username TEXT NOT NULL UNIQUE,
  pin_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('director','teacher')),
  assigned_class TEXT,             -- NULL for director (sees all classes)
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  failed_attempts INTEGER NOT NULL DEFAULT 0,
  locked_until TEXT
);

CREATE TABLE IF NOT EXISTS students (
  id TEXT PRIMARY KEY,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  dob TEXT NOT NULL,
  class_grade TEXT NOT NULL,
  enrollment_year TEXT,
  photo_path TEXT,                  -- relative path in app-private storage, not MediaStore
  guardian_contacts TEXT,           -- JSON array: [{name, relation, phone, email}]
  emergency_contacts TEXT,          -- JSON array
  medical_notes TEXT,               -- free text; treat as sensitive, see retention policy
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','archived')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  created_by TEXT NOT NULL,
  updated_by TEXT NOT NULL,
  archived_at TEXT,
  archived_by TEXT,
  archive_reason TEXT
);

CREATE TABLE IF NOT EXISTS audit_log (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  username TEXT NOT NULL,
  action TEXT NOT NULL,             -- login | login_fail | logout | view | create | update | archive | restore | export
  entity_type TEXT,                 -- 'student' | 'user' | NULL for auth events
  entity_id TEXT,
  detail TEXT,
  timestamp TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_students_class ON students(class_grade);
CREATE INDEX IF NOT EXISTS idx_students_status ON students(status);
CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_log(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_log(user_id);
`;
