import bcrypt from 'bcryptjs';
import { v4 as uuid } from 'uuid';
import { getDb } from './database';
import { logAudit } from './audit';

export type Role = 'director' | 'teacher';

export interface UserRow {
  id: string;
  full_name: string;
  username: string;
  pin_hash: string;
  role: Role;
  assigned_class: string | null;
  active: number;
  failed_attempts: number;
  locked_until: string | null;
}

const MAX_ATTEMPTS = 5;
const LOCK_MINUTES = 15;

export async function createUser(params: {
  fullName: string;
  username: string;
  pin: string;
  role: Role;
  assignedClass?: string;
}): Promise<void> {
  const db = getDb();
  if (params.role === 'teacher' && !params.assignedClass) {
    throw new Error('A teacher account must have an assigned class');
  }
  const pinHash = await bcrypt.hash(params.pin, 12);
  await db.run(
    `INSERT INTO users (id, full_name, username, pin_hash, role, assigned_class, active, created_at)
     VALUES (?, ?, ?, ?, ?, ?, 1, ?)`,
    [uuid(), params.fullName, params.username, pinHash, params.role, params.assignedClass ?? null, new Date().toISOString()]
  );
}

/**
 * PIN/password login with lockout after repeated failures — mitigates
 * brute-forcing a short PIN on a device that's physically accessible to
 * students. Every attempt, success or failure, is written to the audit log.
 */
export async function login(username: string, pin: string): Promise<UserRow> {
  const db = getDb();
  const res = await db.query('SELECT * FROM users WHERE username = ? AND active = 1', [username]);
  const user: UserRow | undefined = res.values?.[0];

  if (!user) {
    throw new Error('Incorrect username or PIN');
  }

  if (user.locked_until && new Date(user.locked_until) > new Date()) {
    throw new Error(`Account locked. Try again after ${new Date(user.locked_until).toLocaleTimeString()}`);
  }

  const valid = await bcrypt.compare(pin, user.pin_hash);
  if (!valid) {
    const attempts = user.failed_attempts + 1;
    const lockedUntil = attempts >= MAX_ATTEMPTS ? new Date(Date.now() + LOCK_MINUTES * 60_000).toISOString() : null;
    await db.run('UPDATE users SET failed_attempts = ?, locked_until = ? WHERE id = ?', [
      attempts,
      lockedUntil,
      user.id,
    ]);
    await db.run(
      `INSERT INTO audit_log (id, user_id, username, action, entity_type, entity_id, detail, timestamp)
       VALUES (?, ?, ?, 'login_fail', NULL, NULL, ?, ?)`,
      [uuid(), user.id, user.username, lockedUntil ? 'locked after max attempts' : null, new Date().toISOString()]
    );
    throw new Error('Incorrect username or PIN');
  }

  await db.run('UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE id = ?', [user.id]);
  await logAudit(
    { id: user.id, username: user.username, role: user.role, assigned_class: user.assigned_class, fullName: user.full_name },
    'login',
    null,
    null,
    null
  );
  return user;
}

export async function changePin(userId: string, newPin: string): Promise<void> {
  const db = getDb();
  const pinHash = await bcrypt.hash(newPin, 12);
  await db.run('UPDATE users SET pin_hash = ? WHERE id = ?', [pinHash, userId]);
}

export async function listUsers(): Promise<Omit<UserRow, 'pin_hash'>[]> {
  const db = getDb();
  const res = await db.query('SELECT id, full_name, username, role, assigned_class, active, failed_attempts, locked_until FROM users ORDER BY full_name');
  return res.values ?? [];
}

export async function deactivateUser(userId: string): Promise<void> {
  const db = getDb();
  await db.run('UPDATE users SET active = 0 WHERE id = ?', [userId]);
}
