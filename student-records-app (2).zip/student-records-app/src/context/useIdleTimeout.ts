import { useEffect, useRef } from 'react';
import { App } from '@capacitor/app';
import { useAuth } from './AuthContext';

const TIMEOUT_MS = 3 * 60_000; // 3 minutes idle — adjust in Settings for your school's risk tolerance
const ACTIVITY_EVENTS = ['pointerdown', 'keydown', 'touchstart', 'scroll'];

/**
 * Auto-locks the session (logs out) after inactivity, and immediately on
 * backgrounding the app — a tablet handed to a student or left on a desk
 * should not sit on an unlocked student list.
 */
export function useIdleTimeout() {
  const { user, logout } = useAuth();
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (!user) return;

    const reset = () => {
      if (timer.current) clearTimeout(timer.current);
      timer.current = setTimeout(() => logout('timeout'), TIMEOUT_MS);
    };

    ACTIVITY_EVENTS.forEach((evt) => window.addEventListener(evt, reset, { passive: true }));
    reset();

    const backgroundSub = App.addListener('appStateChange', ({ isActive }) => {
      if (!isActive) logout('timeout');
    });

    return () => {
      if (timer.current) clearTimeout(timer.current);
      ACTIVITY_EVENTS.forEach((evt) => window.removeEventListener(evt, reset));
      backgroundSub.then((s) => s.remove());
    };
  }, [user, logout]);
}
