import React, { createContext, useContext, useState, useCallback } from 'react';
import * as usersDb from '../db/users';
import { logAudit } from '../db/audit';

export interface AuthUser {
  id: string;
  username: string;
  fullName: string;
  role: 'director' | 'teacher';
  assigned_class: string | null;
}

interface AuthContextValue {
  user: AuthUser | null;
  login: (username: string, pin: string) => Promise<void>;
  logout: (reason?: 'manual' | 'timeout') => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

// Session state lives only in memory (React state), never persisted to disk.
// A killed/restarted app always lands back on the login screen — this is
// deliberate, not a bug, given the device may be shared.
export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);

  const login = useCallback(async (username: string, pin: string) => {
    const row = await usersDb.login(username, pin);
    setUser({
      id: row.id,
      username: row.username,
      fullName: row.full_name,
      role: row.role,
      assigned_class: row.assigned_class,
    });
  }, []);

  const logout = useCallback(
    async (reason: 'manual' | 'timeout' = 'manual') => {
      if (user) {
        await logAudit(user, reason === 'timeout' ? 'session_timeout' : 'logout', null, null, null);
      }
      setUser(null);
    },
    [user]
  );

  return <AuthContext.Provider value={{ user, login, logout }}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
