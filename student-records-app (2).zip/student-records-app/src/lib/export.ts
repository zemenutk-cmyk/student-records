import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import ExcelJS from 'exceljs';
import { Filesystem, Directory } from '@capacitor/filesystem';
import type { Student } from '../db/students';
import type { AuthUser } from '../context/AuthContext';
import { logAudit } from '../db/audit';

// Exports are a deliberate exfiltration point for a database like this one,
// so every export is: (a) scoped to what the actor is already allowed to
// see (callers must pass an already-role-filtered student list), (b)
// written to app-private storage rather than public Downloads, and (c)
// logged with a row count so a director can see who exported what and when.

async function writeAndLog(actor: AuthUser, filename: string, base64: string, count: number, kind: 'pdf' | 'xlsx') {
  await Filesystem.writeFile({
    path: filename,
    data: base64,
    directory: Directory.Data, // app-private storage, not shared/public storage
  });
  await logAudit(actor, 'export', 'student', null, `${kind} export, ${count} record(s), file: ${filename}`);
  return filename;
}

export async function exportStudentsToPdf(actor: AuthUser, students: Student[], title = 'Student Roster'): Promise<string> {
  const doc = new jsPDF();
  doc.setFontSize(14);
  doc.text(title, 14, 16);
  doc.setFontSize(9);
  doc.text(`Generated ${new Date().toLocaleString()} by ${actor.fullName} — CONFIDENTIAL`, 14, 22);

  autoTable(doc, {
    startY: 28,
    head: [['Name', 'DOB', 'Class', 'Guardian Contact', 'Medical Notes']],
    body: students.map((s) => [
      `${s.first_name} ${s.last_name}`,
      s.dob,
      s.class_grade,
      s.guardian_contacts[0] ? `${s.guardian_contacts[0].name} (${s.guardian_contacts[0].phone})` : '—',
      s.medical_notes ? s.medical_notes.slice(0, 60) : '—',
    ]),
    styles: { fontSize: 8 },
  });

  const base64 = doc.output('datauristring').split(',')[1];
  const filename = `student-roster-${Date.now()}.pdf`;
  return writeAndLog(actor, filename, base64, students.length, 'pdf');
}

export async function exportStudentsToExcel(actor: AuthUser, students: Student[]): Promise<string> {
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Students');
  ws.columns = [
    { header: 'First name', key: 'first_name', width: 16 },
    { header: 'Last name', key: 'last_name', width: 16 },
    { header: 'DOB', key: 'dob', width: 12 },
    { header: 'Class', key: 'class_grade', width: 10 },
    { header: 'Guardian name', key: 'guardian_name', width: 20 },
    { header: 'Guardian phone', key: 'guardian_phone', width: 16 },
    { header: 'Emergency contact', key: 'emergency', width: 24 },
    { header: 'Medical notes', key: 'medical_notes', width: 30 },
  ];
  students.forEach((s) => {
    ws.addRow({
      first_name: s.first_name,
      last_name: s.last_name,
      dob: s.dob,
      class_grade: s.class_grade,
      guardian_name: s.guardian_contacts[0]?.name ?? '',
      guardian_phone: s.guardian_contacts[0]?.phone ?? '',
      emergency: s.emergency_contacts.map((c) => `${c.name} (${c.phone})`).join('; '),
      medical_notes: s.medical_notes ?? '',
    });
  });
  ws.getRow(1).font = { bold: true };

  const buffer = await wb.xlsx.writeBuffer();
  const base64 = arrayBufferToBase64(buffer as ArrayBuffer);
  const filename = `student-roster-${Date.now()}.xlsx`;
  return writeAndLog(actor, filename, base64, students.length, 'xlsx');
}

function arrayBufferToBase64(buffer: ArrayBuffer): string {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}
