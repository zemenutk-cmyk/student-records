import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { listAuditLog, AuditRow } from '../db/audit';

export default function AuditLog() {
  const { user } = useAuth();
  const [rows, setRows] = useState<AuditRow[]>([]);

  useEffect(() => {
    if (!user || user.role !== 'director') return;
    listAuditLog(user).then(setRows);
  }, [user]);

  if (!user || user.role !== 'director') {
    return <div className="p-6 text-sm text-alert-600">Only a director can view the audit log.</div>;
  }

  return (
    <div className="min-h-screen max-w-3xl mx-auto p-4">
      <Link to="/students" className="text-sm text-moss-700 hover:underline">
        ← Back to list
      </Link>
      <h1 className="text-lg text-ink mt-3 mb-3">Audit log</h1>
      <div className="bg-white border border-slate-200 rounded-md overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-slate-100 text-left text-xs uppercase text-slate-400">
            <tr>
              <th className="px-3 py-2">Time</th>
              <th className="px-3 py-2">User</th>
              <th className="px-3 py-2">Action</th>
              <th className="px-3 py-2">Detail</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-t border-slate-100">
                <td className="px-3 py-2 whitespace-nowrap text-slate-400">{new Date(r.timestamp).toLocaleString()}</td>
                <td className="px-3 py-2">{r.username}</td>
                <td className="px-3 py-2">{r.action}</td>
                <td className="px-3 py-2 text-slate-600">{r.detail ?? '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {rows.length === 0 && <p className="text-center text-slate-400 text-sm py-8">No entries yet.</p>}
      </div>
    </div>
  );
}
