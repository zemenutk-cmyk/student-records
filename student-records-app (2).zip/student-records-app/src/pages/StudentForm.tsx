import React, { useEffect, useState } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';
import { useAuth } from '../context/AuthContext';
import { getStudent, createStudent, updateStudent, Contact } from '../db/students';

const emptyContact: Contact = { name: '', relation: '', phone: '', email: '' };

export default function StudentForm() {
  const { id } = useParams<{ id: string }>();
  const isEdit = Boolean(id);
  const { user } = useAuth();
  const navigate = useNavigate();

  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [dob, setDob] = useState('');
  const [classGrade, setClassGrade] = useState(user?.role === 'teacher' ? user.assigned_class ?? '' : '');
  const [enrollmentYear, setEnrollmentYear] = useState('');
  const [photoPath, setPhotoPath] = useState<string | undefined>();
  const [guardianContacts, setGuardianContacts] = useState<Contact[]>([{ ...emptyContact }]);
  const [emergencyContacts, setEmergencyContacts] = useState<Contact[]>([{ ...emptyContact }]);
  const [medicalNotes, setMedicalNotes] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!user || !id) return;
    getStudent(user, id).then((s) => {
      if (!s) return;
      setFirstName(s.first_name);
      setLastName(s.last_name);
      setDob(s.dob);
      setClassGrade(s.class_grade);
      setEnrollmentYear(s.enrollment_year ?? '');
      setPhotoPath(s.photo_path);
      setGuardianContacts(s.guardian_contacts.length ? s.guardian_contacts : [{ ...emptyContact }]);
      setEmergencyContacts(s.emergency_contacts.length ? s.emergency_contacts : [{ ...emptyContact }]);
      setMedicalNotes(s.medical_notes ?? '');
    });
  }, [user, id]);

  if (!user) return null;

  async function takePhoto() {
    // Camera-only capture — the app never requests broad photo-library or
    // storage-wide permissions, just this single-purpose capture flow.
    const photo = await Camera.getPhoto({
      resultType: CameraResultType.DataUrl,
      source: CameraSource.Camera,
      quality: 70,
      width: 480,
    });
    setPhotoPath(photo.dataUrl);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = {
        first_name: firstName.trim(),
        last_name: lastName.trim(),
        dob,
        class_grade: classGrade.trim(),
        enrollment_year: enrollmentYear.trim() || undefined,
        photo_path: photoPath,
        guardian_contacts: guardianContacts.filter((c) => c.name.trim()),
        emergency_contacts: emergencyContacts.filter((c) => c.name.trim()),
        medical_notes: medicalNotes.trim() || undefined,
      };
      if (isEdit && id) {
        await updateStudent(user, id, payload);
        navigate(`/students/${id}`);
      } else {
        const created = await createStudent(user, payload);
        navigate(`/students/${created.id}`);
      }
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="min-h-screen max-w-2xl mx-auto p-4">
      <Link to="/students" className="text-sm text-moss-700 hover:underline">
        ← Cancel
      </Link>

      <form onSubmit={handleSubmit} className="bg-white border border-slate-200 rounded-md mt-3 p-5 space-y-5">
        <h1 className="text-lg text-ink">{isEdit ? 'Edit student' : 'Add student'}</h1>

        <div className="flex items-center gap-3">
          <div className="h-16 w-16 rounded-full bg-slate-100 overflow-hidden flex items-center justify-center text-xs text-slate-400">
            {photoPath ? <img src={photoPath} alt="" className="h-full w-full object-cover" /> : 'No photo'}
          </div>
          <button type="button" onClick={takePhoto} className="text-sm rounded-md border border-slate-200 px-3 py-1.5 hover:bg-slate-100">
            {photoPath ? 'Retake photo' : 'Take photo'}
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <Field label="First name" value={firstName} onChange={setFirstName} required />
          <Field label="Last name" value={lastName} onChange={setLastName} required />
          <Field label="Date of birth" type="date" value={dob} onChange={setDob} required />
          <Field label="Class / grade" value={classGrade} onChange={setClassGrade} required disabled={user.role === 'teacher'} />
          <Field label="Enrollment year" value={enrollmentYear} onChange={setEnrollmentYear} />
        </div>

        <ContactGroup title="Guardian contacts" contacts={guardianContacts} setContacts={setGuardianContacts} />
        <ContactGroup title="Emergency contacts" contacts={emergencyContacts} setContacts={setEmergencyContacts} />

        <div>
          <label className="block text-sm font-medium text-slate-600 mb-1">Medical notes</label>
          <textarea
            value={medicalNotes}
            onChange={(e) => setMedicalNotes(e.target.value)}
            rows={3}
            placeholder="Only record what staff need to keep the student safe (allergies, conditions, medication)."
            className="w-full rounded-md border border-slate-200 px-3 py-2 text-sm"
          />
        </div>

        <button
          type="submit"
          disabled={saving}
          className="w-full rounded-md bg-moss-600 text-white py-2.5 font-medium hover:bg-moss-700 disabled:opacity-60"
        >
          {saving ? 'Saving…' : 'Save record'}
        </button>
      </form>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  type = 'text',
  required,
  disabled,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  required?: boolean;
  disabled?: boolean;
}) {
  return (
    <div>
      <label className="block text-sm font-medium text-slate-600 mb-1">{label}</label>
      <input
        type={type}
        value={value}
        disabled={disabled}
        onChange={(e) => onChange(e.target.value)}
        required={required}
        className="w-full rounded-md border border-slate-200 px-3 py-2 text-sm disabled:bg-slate-100"
      />
    </div>
  );
}

function ContactGroup({
  title,
  contacts,
  setContacts,
}: {
  title: string;
  contacts: Contact[];
  setContacts: (c: Contact[]) => void;
}) {
  function update(i: number, field: keyof Contact, value: string) {
    const next = [...contacts];
    next[i] = { ...next[i], [field]: value };
    setContacts(next);
  }
  return (
    <div>
      <div className="flex items-center justify-between mb-1.5">
        <label className="text-sm font-medium text-slate-600">{title}</label>
        <button type="button" onClick={() => setContacts([...contacts, { ...emptyContact }])} className="text-xs text-moss-700 hover:underline">
          + Add contact
        </button>
      </div>
      <div className="space-y-2">
        {contacts.map((c, i) => (
          <div key={i} className="grid grid-cols-4 gap-2">
            <input placeholder="Name" value={c.name} onChange={(e) => update(i, 'name', e.target.value)} className="rounded-md border border-slate-200 px-2 py-1.5 text-sm col-span-1" />
            <input placeholder="Relation" value={c.relation} onChange={(e) => update(i, 'relation', e.target.value)} className="rounded-md border border-slate-200 px-2 py-1.5 text-sm col-span-1" />
            <input placeholder="Phone" value={c.phone} onChange={(e) => update(i, 'phone', e.target.value)} className="rounded-md border border-slate-200 px-2 py-1.5 text-sm col-span-1" />
            <input placeholder="Email (optional)" value={c.email ?? ''} onChange={(e) => update(i, 'email', e.target.value)} className="rounded-md border border-slate-200 px-2 py-1.5 text-sm col-span-1" />
          </div>
        ))}
      </div>
    </div>
  );
}
