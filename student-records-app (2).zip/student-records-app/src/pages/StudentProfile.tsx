import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getStudent, archiveStudent, restoreStudent, Student } from '../db/students';

export default function StudentProfile() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [student, setStudent] = useState<Student | null>(null);
  const [archiveReason, setArchiveReason] = useState('');
  const [showArchiveForm, setShowArchiveForm] = useState(false);

  useEffect(() => {
    if (!user || !id) return;
    getStudent(user, id).then(setStudent);
  }, [user, id]);

  if (!user || !student) return <div className="p-6 text-slate-400">Loading…</div>;

  async function handleArchive() {
    if (!archiveReason.trim()) return;
    await archiveStudent(user!, student!.id, archiveReason.trim());
    navigate('/students');
  }

  async function handleRestore() {
    await restoreStudent(user!, student!.id);
    setStudent({ ...student!, status: 'active' });
  }

  return (
    <div className="min-h-screen max-w-2xl mx-auto p-4">
      <Link to="/students" className="text-sm text-moss-700 hover:underline">
        ← Back to list
      </Link>

      <div className="bg-white border border-slate-200 rounded-md mt-3 p-5">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-xl text-ink">
              {student.first_name} {student.last_name}
            </h1>
            <p className="text-sm text-slate-400">
              Class {student.class_grade} · DOB {student.dob}
              {student.status === 'archived' && <span className="ml-2 text-alert-500">Archived</span>}
            </p>
          </div>
          <Link to={`/students/${student.id}/edit`} className="text-sm rounded-md border border-slate-200 px-3 py-1.5 hover:bg-slate-100">
            Edit
          </Link>
        </div>

        <Section title="Guardian contacts">
          <ContactList contacts={student.guardian_contacts} empty="No guardian contacts recorded." />
        </Section>

        <Section title="Emergency contacts">
          <ContactList contacts={student.emergency_contacts} empty="No emergency contacts recorded." />
        </Section>

        <Section title="Medical notes">
          <p className="text-sm text-ink whitespace-pre-wrap">{student.medical_notes || 'None recorded.'}</p>
        </Section>

        <div className="mt-6 pt-4 border-t border-slate-200 text-xs text-slate-400">
          Last updated {new Date(student.updated_at).toLocaleString()}
        </div>

        <div className="mt-4">
          {student.status === 'active' ? (
            !showArchiveForm ? (
              <button onClick={() => setShowArchiveForm(true)} className="text-sm text-alert-600 hover:underline">
                Archive record
              </button>
            ) : (
              <div className="space-y-2">
                <label className="block text-sm text-slate-600">Reason for archiving (required, kept for audit)</label>
                <input
                  value={archiveReason}
                  onChange={(e) => setArchiveReason(e.target.value)}
                  className="w-full rounded-md border border-slate-200 px-3 py-2 text-sm"
                  placeholder="e.g. Student left the school, June 2026"
                />
                <div className="flex gap-2">
                  <button onClick={handleArchive} className="rounded-md bg-alert-600 text-white text-sm px-3 py-2 hover:bg-alert-500">
                    Confirm archive
                  </button>
                  <button onClick={() => setShowArchiveForm(false)} className="text-sm text-slate-600 px-3 py-2">
                    Cancel
                  </button>
                </div>
              </div>
            )
          ) : (
            user.role === 'director' && (
              <button onClick={handleRestore} className="text-sm text-moss-700 hover:underline">
                Restore record
              </button>
            )
          )}
        </div>
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mt-5">
      <h2 className="text-xs uppercase tracking-wide text-slate-400 mb-1.5">{title}</h2>
      {children}
    </div>
  );
}

function ContactList({ contacts, empty }: { contacts: { name: string; relation: string; phone: string; email?: string }[]; empty: string }) {
  if (!contacts.length) return <p className="text-sm text-slate-400">{empty}</p>;
  return (
    <ul className="space-y-1.5">
      {contacts.map((c, i) => (
        <li key={i} className="text-sm text-ink">
          {c.name} <span className="text-slate-400">({c.relation})</span> — {c.phone}
          {c.email && <span className="text-slate-400"> · {c.email}</span>}
        </li>
      ))}
    </ul>
  );
}
