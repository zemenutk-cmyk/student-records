import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';

export default function Login() {
  const { login } = useAuth();
  const [username, setUsername] = useState('');
  const [pin, setPin] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      await login(username.trim(), pin);
    } catch (err: any) {
      setError(err.message ?? 'Sign in failed');
    } finally {
      setBusy(false);
      setPin('');
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-6">
      <div className="w-full max-w-sm">
        <div className="mb-8 text-center">
          <div className="mx-auto mb-3 h-10 w-10 rounded-md bg-moss-600" aria-hidden />
          <h1 className="text-2xl text-ink">Student Records</h1>
          <p className="text-slate-600 text-sm mt-1">Sign in to continue</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="username" className="block text-sm font-medium text-slate-600 mb-1">
              Username
            </label>
            <input
              id="username"
              autoComplete="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-ink focus:border-moss-500"
              required
            />
          </div>
          <div>
            <label htmlFor="pin" className="block text-sm font-medium text-slate-600 mb-1">
              PIN
            </label>
            <input
              id="pin"
              type="password"
              inputMode="numeric"
              autoComplete="current-password"
              value={pin}
              onChange={(e) => setPin(e.target.value)}
              className="w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-ink focus:border-moss-500 tracking-widest"
              required
            />
          </div>

          {error && (
            <p role="alert" className="text-sm text-alert-600 bg-alert-100 rounded-sm px-3 py-2">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={busy}
            className="w-full rounded-md bg-moss-600 text-white py-2.5 font-medium hover:bg-moss-700 disabled:opacity-60"
          >
            {busy ? 'Signing in…' : 'Sign in'}
          </button>
        </form>

        <p className="text-xs text-slate-400 text-center mt-6">
          This device holds records about children. Sign out when you step away.
        </p>
      </div>
    </div>
  );
}
