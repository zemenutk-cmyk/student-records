import React, { useEffect, useState, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { listStudents, Student } from '../db/students';
import { exportStudentsToPdf, exportStudentsToExcel } from '../lib/export';

export default function StudentList() {
  const { user, logout } = useAuth();
  const [students, setStudents] = useState<Student[]>([]);
  const [search, setSearch] = useState('');
  const [classFilter, setClassFilter] = useState('');
  const [showArchived, setShowArchived] = useState(false);
  const [exporting, setExporting] = useState<'pdf' | 'xlsx' | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    if (!user) return;
    const rows = await listStudents(user, { search, classGrade: classFilter || undefined, includeArchived: showArchived });
    setStudents(rows);
  }, [user, search, classFilter, showArchived]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  if (!user) return null;

  async function handleExport(kind: 'pdf' | 'xlsx') {
    setExporting(kind);
    setMessage(null);
    try {
      const path = kind === 'pdf' ? await exportStudentsToPdf(user!, students) : await exportStudentsToExcel(user!, students);
      setMessage(`Saved to app storage: ${path}`);
    } finally {
      setExporting(null);
    }
  }

  return (
    <div className="min-h-screen">
      <header className="border-b border-slate-200 bg-white px-4 py-3 flex items-center justify-between">
        <div>
          <h1 className="text-lg text-ink">Student Records</h1>
          <p className="text-xs text-slate-400">
            {user.fullName} · {user.role === 'director' ? 'Director — all classes' : `Class ${user.assigned_class}`}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {user.role === 'director' && (
            <>
              <Link to="/settings" className="text-sm text-moss-700 hover:underline">
                Staff
              </Link>
              <Link to="/audit" className="text-sm text-moss-700 hover:underline">
                Audit log
              </Link>
            </>
          )}
          <button onClick={() => logout('manual')} className="text-sm text-slate-600 hover:text-ink">
            Sign out
          </button>
        </div>
      </header>

      <main className="p-4 max-w-3xl mx-auto">
        <div className="flex flex-wrap gap-2 mb-4">
          <input
            placeholder="Search by name…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="flex-1 min-w-[160px] rounded-md border border-slate-200 bg-white px-3 py-2 text-sm"
          />
          {user.role === 'director' && (
            <input
              placeholder="Filter by class"
              value={classFilter}
              onChange={(e) => setClassFilter(e.target.value)}
              className="w-32 rounded-md border border-slate-200 bg-white px-3 py-2 text-sm"
            />
          )}
          <label className="flex items-center gap-1.5 text-sm text-slate-600 px-1">
            <input type="checkbox" checked={showArchived} onChange={(e) => setShowArchived(e.target.checked)} />
            Show archived
          </label>
        </div>

        <div className="flex items-center justify-between mb-3">
          <Link to="/students/new" className="rounded-md bg-moss-600 text-white text-sm px-3 py-2 hover:bg-moss-700">
            + Add student
          </Link>
          <div className="flex gap-2">
            <button
              onClick={() => handleExport('pdf')}
              disabled={exporting !== null || students.length === 0}
              className="text-sm rounded-md border border-slate-200 px-3 py-2 hover:bg-slate-100 disabled:opacity-50"
            >
              {exporting === 'pdf' ? 'Exporting…' : 'Export PDF'}
            </button>
            <button
              onClick={() => handleExport('xlsx')}
              disabled={exporting !== null || students.length === 0}
              className="text-sm rounded-md border border-slate-200 px-3 py-2 hover:bg-slate-100 disabled:opacity-50"
            >
              {exporting === 'xlsx' ? 'Exporting…' : 'Export Excel'}
            </button>
          </div>
        </div>

        {message && <p className="text-xs text-moss-700 mb-3">{message}</p>}

        <ul className="divide-y divide-slate-200 bg-white rounded-md border border-slate-200 no-callout">
          {students.map((s) => (
            <li key={s.id}>
              <Link to={`/students/${s.id}`} className="flex items-center gap-3 px-4 py-3 hover:bg-slate-100">
                <div className="h-9 w-9 rounded-full bg-slate-100 flex items-center justify-center text-sm text-slate-600 overflow-hidden">
                  {s.photo_path ? (
                    <img src={s.photo_path} alt="" className="h-full w-full object-cover" />
                  ) : (
                    `${s.first_name[0]}${s.last_name[0]}`
                  )}
                </div>
                <div className="flex-1">
                  <p className="text-sm text-ink">
                    {s.first_name} {s.last_name}
                    {s.status === 'archived' && <span className="ml-2 text-xs text-alert-500">Archived</span>}
                  </p>
                  <p className="text-xs text-slate-400">Class {s.class_grade}</p>
                </div>
              </Link>
            </li>
          ))}
          {students.length === 0 && <li className="px-4 py-8 text-center text-sm text-slate-400">No records match.</li>}
        </ul>
      </main>
    </div>
  );
}
