import React, { useState } from 'react';
import { createUser } from '../db/users';

export default function SetupDirector({ onDone }: { onDone: () => void }) {
  const [fullName, setFullName] = useState('');
  const [username, setUsername] = useState('');
  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (pin.length < 6) {
      setError('Use a PIN of at least 6 digits — this account can see every record in the school.');
      return;
    }
    if (pin !== confirmPin) {
      setError('PINs do not match.');
      return;
    }
    setBusy(true);
    try {
      await createUser({ fullName: fullName.trim(), username: username.trim(), pin, role: 'director' });
      onDone();
    } catch (err: any) {
      setError(err.message ?? 'Could not create account');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-6">
      <div className="w-full max-w-sm">
        <h1 className="text-xl text-ink mb-1">Set up this school's records</h1>
        <p className="text-sm text-slate-600 mb-6">
          Create the director account. This account can see and manage every student record and every staff account, and
          is the only one that can view the audit log. Add teacher accounts afterward, one per class, from Settings.
        </p>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            placeholder="Full name"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            className="w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-sm"
            required
          />
          <input
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-sm"
            required
          />
          <input
            type="password"
            inputMode="numeric"
            placeholder="PIN (6+ digits)"
            value={pin}
            onChange={(e) => setPin(e.target.value)}
            className="w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-sm tracking-widest"
            required
          />
          <input
            type="password"
            inputMode="numeric"
            placeholder="Confirm PIN"
            value={confirmPin}
            onChange={(e) => setConfirmPin(e.target.value)}
            className="w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-sm tracking-widest"
            required
          />
          {error && <p className="text-sm text-alert-600 bg-alert-100 rounded-sm px-3 py-2">{error}</p>}
          <button
            type="submit"
            disabled={busy}
            className="w-full rounded-md bg-moss-600 text-white py-2.5 font-medium hover:bg-moss-700 disabled:opacity-60"
          >
            {busy ? 'Creating…' : 'Create director account'}
          </button>
        </form>
      </div>
    </div>
  );
}
