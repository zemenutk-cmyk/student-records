import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { createUser, listUsers, deactivateUser, UserRow } from '../db/users';

export default function Settings() {
  const { user } = useAuth();
  const [users, setUsers] = useState<Omit<UserRow, 'pin_hash'>[]>([]);
  const [fullName, setFullName] = useState('');
  const [username, setUsername] = useState('');
  const [pin, setPin] = useState('');
  const [assignedClass, setAssignedClass] = useState('');
  const [error, setError] = useState<string | null>(null);

  async function refresh() {
    setUsers(await listUsers());
  }

  useEffect(() => {
    if (user?.role === 'director') refresh();
  }, [user]);

  if (!user || user.role !== 'director') {
    return <div className="p-6 text-sm text-alert-600">Only a director can manage staff accounts.</div>;
  }

  async function handleAddTeacher(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      await createUser({ fullName, username, pin, role: 'teacher', assignedClass });
      setFullName('');
      setUsername('');
      setPin('');
      setAssignedClass('');
      await refresh();
    } catch (err: any) {
      setError(err.message ?? 'Could not create account');
    }
  }

  return (
    <div className="min-h-screen max-w-2xl mx-auto p-4">
      <Link to="/students" className="text-sm text-moss-700 hover:underline">
        ← Back to list
      </Link>
      <h1 className="text-lg text-ink mt-3 mb-4">Staff accounts</h1>

      <div className="bg-white border border-slate-200 rounded-md p-4 mb-6">
        <h2 className="text-sm font-medium text-slate-600 mb-3">Add a teacher</h2>
        <form onSubmit={handleAddTeacher} className="grid grid-cols-2 gap-2">
          <input placeholder="Full name" value={fullName} onChange={(e) => setFullName(e.target.value)} className="rounded-md border border-slate-200 px-3 py-2 text-sm col-span-1" required />
          <input placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} className="rounded-md border border-slate-200 px-3 py-2 text-sm col-span-1" required />
          <input placeholder="Assigned class" value={assignedClass} onChange={(e) => setAssignedClass(e.target.value)} className="rounded-md border border-slate-200 px-3 py-2 text-sm col-span-1" required />
          <input type="password" inputMode="numeric" placeholder="Starting PIN (6+ digits)" value={pin} onChange={(e) => setPin(e.target.value)} className="rounded-md border border-slate-200 px-3 py-2 text-sm col-span-1" required minLength={6} />
          {error && <p className="col-span-2 text-sm text-alert-600">{error}</p>}
          <button type="submit" className="col-span-2 rounded-md bg-moss-600 text-white py-2 text-sm hover:bg-moss-700">
            Add teacher account
          </button>
        </form>
        <p className="text-xs text-slate-400 mt-2">
          A teacher sees only students in their assigned class. Have them change their PIN after first sign-in.
        </p>
      </div>

      <div className="bg-white border border-slate-200 rounded-md overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-slate-100 text-left text-xs uppercase text-slate-400">
            <tr>
              <th className="px-3 py-2">Name</th>
              <th className="px-3 py-2">Role</th>
              <th className="px-3 py-2">Class</th>
              <th className="px-3 py-2">Status</th>
              <th className="px-3 py-2" />
            </tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id} className="border-t border-slate-100">
                <td className="px-3 py-2">{u.full_name}</td>
                <td className="px-3 py-2">{u.role}</td>
                <td className="px-3 py-2">{u.assigned_class ?? '—'}</td>
                <td className="px-3 py-2">{u.active ? 'Active' : 'Deactivated'}</td>
                <td className="px-3 py-2 text-right">
                  {u.active && u.id !== user.id && (
                    <button onClick={() => deactivateUser(u.id).then(refresh)} className="text-xs text-alert-600 hover:underline">
                      Deactivate
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
