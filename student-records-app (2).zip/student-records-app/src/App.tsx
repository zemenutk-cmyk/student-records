import React, { useEffect, useState } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { useIdleTimeout } from './context/useIdleTimeout';
import { initDatabase, getDb } from './db/database';
import Login from './pages/Login';
import StudentList from './pages/StudentList';
import StudentProfile from './pages/StudentProfile';
import StudentForm from './pages/StudentForm';
import AuditLog from './pages/AuditLog';
import Settings from './pages/Settings';
import SetupDirector from './pages/SetupDirector';

function Protected({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  return <>{children}</>;
}

function Shell() {
  useIdleTimeout();
  const { user } = useAuth();

  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to="/students" replace /> : <Login />} />
      <Route
        path="/students"
        element={
          <Protected>
            <StudentList />
          </Protected>
        }
      />
      <Route
        path="/students/new"
        element={
          <Protected>
            <StudentForm />
          </Protected>
        }
      />
      <Route
        path="/students/:id"
        element={
          <Protected>
            <StudentProfile />
          </Protected>
        }
      />
      <Route
        path="/students/:id/edit"
        element={
          <Protected>
            <StudentForm />
          </Protected>
        }
      />
      <Route
        path="/audit"
        element={
          <Protected>
            <AuditLog />
          </Protected>
        }
      />
      <Route
        path="/settings"
        element={
          <Protected>
            <Settings />
          </Protected>
        }
      />
      <Route path="*" element={<Navigate to="/students" replace />} />
    </Routes>
  );
}

export default function App() {
  const [ready, setReady] = useState(false);
  const [needsSetup, setNeedsSetup] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    initDatabase()
      .then(async () => {
        const res = await getDb().query('SELECT COUNT(*) as n FROM users');
        setNeedsSetup((res.values?.[0]?.n ?? 0) === 0);
        setReady(true);
      })
      .catch((e) => setError(e.message ?? 'Failed to open database'));
  }, []);

  if (error) {
    return <div className="p-6 text-alert-600 text-sm">Could not open the encrypted database: {error}</div>;
  }
  if (!ready) {
    return <div className="min-h-screen flex items-center justify-center text-slate-400 text-sm">Opening secure database…</div>;
  }
  if (needsSetup) {
    return <SetupDirector onDone={() => setNeedsSetup(false)} />;
  }

  return (
    <AuthProvider>
      <HashRouter>
        <Shell />
      </HashRouter>
    </AuthProvider>
  );
}
