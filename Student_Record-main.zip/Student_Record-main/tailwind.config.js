/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        // Calm, institutional palette: this is a records app handling
        // sensitive data about children, not a consumer product — the
        // UI should read as trustworthy, quiet, and legible, not flashy.
        ink: '#1C2A2E',        // near-black slate, primary text
        paper: '#F6F5F1',      // warm off-white background
        slate: {
          50: '#F6F5F1',
          100: '#EAE8E1',
          200: '#D3D0C6',
          400: '#8B9490',
          600: '#4B5A57',
          800: '#243334',
          900: '#1C2A2E',
        },
        moss: {
          50: '#EEF3EC',
          100: '#D7E3D2',
          400: '#6E8F68',
          500: '#4F7249',
          600: '#3E5B39',
          700: '#2F452B',
        },
        clay: {
          400: '#C97B63',
          500: '#B75F45',
          600: '#95492F',
        },
        alert: {
          100: '#F6E4E1',
          500: '#B23A2E',
          600: '#8F2E24',
        },
      },
      fontFamily: {
        display: ['"Source Serif 4"', 'Georgia', 'serif'],
        body: ['"IBM Plex Sans"', 'system-ui', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'monospace'],
      },
      borderRadius: {
        sm: '4px',
        md: '6px',
      },
    },
  },
  plugins: [],
};
