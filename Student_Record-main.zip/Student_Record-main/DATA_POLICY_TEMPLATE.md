# Student Records — Data Retention & Access Policy (template)

Fill this in and keep it alongside the app before real student data goes in.
It should shape (and, where it already does, matches) the schema and
access-control logic actually built into the app.

## 1. What is collected, and why
| Field | Purpose | Who can see it |
|---|---|---|
| Name, DOB, class/grade | Core identification, class rosters | All staff (scoped to own class for teachers) |
| Photo | Identification on shared tablets | All staff (scoped) |
| Guardian contacts | Day-to-day communication | All staff (scoped) |
| Emergency contacts | Emergency response | All staff (scoped) |
| Medical notes | Safeguarding / duty of care | *(decide: all staff, or director + relevant teacher only)* |

Only fields actually needed should be collected. If a field isn't in the
table above and isn't in the app's schema, don't add it without updating
this policy first.

## 2. Roles
- **Director** — full access to all student records across all classes, staff account management, audit log.
- **Teacher** — access limited to their own assigned class only, cannot view the audit log or manage other accounts.
- *(Add other roles here if your school needs them — e.g. school nurse with medical-notes-only access — and note the schema/access-control change required.)*

## 3. Retention
- Active students: records kept for the duration of enrollment.
- **Leavers**: archived (soft-deleted, `status = 'archived'`) on the date the student leaves — decide and record here how long archived records are kept before hard deletion, e.g. "7 years after leaving" or per your national school-records regulation.
- **Hard deletion**: only performed as a deliberate, director-initiated, audit-logged action after the retention period. Never done by simply deleting rows outside the app's tooling.

## 4. Device & access controls already built in
- PIN-based login, 5 failed attempts locks the account for 15 minutes.
- Session auto-locks after 3 minutes idle or when the app is backgrounded.
- Database encrypted at rest (SQLCipher via `@capacitor-community/sqlite`).
- Every view, create, edit, archive, restore, and export of a student record is written to an append-only audit log, visible only to the director.
- No Android system auto-backup of the raw database (see `android-notes/MANIFEST_HARDENING.md`).

## 5. What happens if a device is lost or stolen
- Document your process here: who to notify, whether remote-wipe is available (Android device management, if the school issues MDM-managed tablets), and how quickly staff PINs should be rotated as a precaution.

## 6. Review
- Review this policy at least yearly, and whenever a new field, role, or integration is added to the app.
