# Student Records

A local-first, encrypted-at-rest student records app for a single school:
profiles, guardian/emergency contacts, medical notes, PIN login with
director/teacher roles, audit log, and PDF/Excel export.

Stack: React + Vite + Tailwind + TypeScript, wrapped with Capacitor for
Android. Storage: SQLite encrypted with SQLCipher via
`@capacitor-community/sqlite` (no backend, no cloud sync — see "Multi-device
access" below if you need that later).

---

## 0. Before you put real student data in this

Read `DATA_POLICY_TEMPLATE.md` and fill it in for your school. Also replace
the placeholder encryption-secret storage — see the big comment block at the
top of `src/db/secureSecret.ts`. Shipping with that placeholder means the
database encryption key sits in plain Android SharedPreferences, which
defeats the purpose of encrypting the database in the first place.

## 1. Install dependencies

```bash
npm install
```

## 2. Run in the browser during development

```bash
npm run dev
```

This uses a WASM (`jeep-sqlite`) fallback for SQLite so you can iterate in a
browser tab. Encryption still applies, but this path is for UI development
only — always test the real encrypted flow on a device before relying on it.

## 3. Add the Android platform

Requires Android Studio + the Android SDK installed locally (not available
in a sandboxed build environment — this step needs your machine).

```bash
npm run build
npx cap add android
npx cap sync android
```

Then apply the manifest hardening steps in
`android-notes/MANIFEST_HARDENING.md` (disable auto-backup, trim
permissions, block cleartext traffic, prevent screenshots) — do this once,
right after `cap add android`, before your first build.

## 4. Run on a device/emulator during development

```bash
npx cap open android
```
Then hit Run in Android Studio, or:
```bash
npx cap run android
```

## 5. Build a signed release APK

### 5a. Generate a keystore (once — keep this file and its passwords safe; losing it means you can never update the app under the same signature)

```bash
keytool -genkey -v -keystore student-records-release.keystore \
  -alias student-records -keyalg RSA -keysize 2048 -validity 10000
```

Store the resulting `.keystore` file and passwords outside the repo (it's
already in `.gitignore`). A password manager or the school's secure
document store, not email, not a shared drive.

### 5b. Configure Gradle signing

Create `android/keystore.properties` (also gitignored):

```properties
storeFile=../../student-records-release.keystore
storePassword=YOUR_STORE_PASSWORD
keyAlias=student-records
keyPassword=YOUR_KEY_PASSWORD
```

In `android/app/build.gradle`, inside `android { }`, add:

```groovy
def keystorePropertiesFile = rootProject.file("keystore.properties")
def keystoreProperties = new Properties()
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}

signingConfigs {
    release {
        storeFile file(keystoreProperties['storeFile'])
        storePassword keystoreProperties['storePassword']
        keyAlias keystoreProperties['keyAlias']
        keyPassword keystoreProperties['keyPassword']
    }
}
buildTypes {
    release {
        signingConfig signingConfigs.release
        minifyEnabled true
        proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
    }
}
```

### 5c. Build

```bash
cd android
./gradlew assembleRelease
```

Output: `android/app/build/outputs/apk/release/app-release.apk`

For a Play Store submission, build an App Bundle instead:
```bash
./gradlew bundleRelease
```
Output: `android/app/build/outputs/bundle/release/app-release.aab`

### 5d. Verify the signature (optional sanity check)

```bash
apksigner verify --print-certs android/app/build/outputs/apk/release/app-release.apk
```

## 6. First run on a fresh install

The app detects zero user accounts on first launch and shows a one-time
setup screen to create the director account. From there, the director signs
in and adds one teacher account per class under **Staff** — each teacher's
account is locked to their `assigned_class` at the database query level (see
`src/db/students.ts`, `scopeClause`), not just hidden in the UI.

## 7. Multi-device access (optional, not built by default)

This build is intentionally local-first/single-device, matching your "no
cloud backup of the raw DB" requirement. If staff later need the same
records across multiple tablets, the clean way to add that without
weakening the encryption-at-rest guarantee is a sync layer (e.g. Supabase
with row-level security matching the same director/teacher scoping already
in `scopeClause`, over HTTPS only) that pushes/pulls encrypted rows rather
than replacing local SQLCipher with an unencrypted synced store. That's a
separate, deliberate follow-up — flag it if you want it scoped out.

## Where the security requirements live in the code

| Requirement | Where |
|---|---|
| PIN login, lockout after failed attempts | `src/db/users.ts` |
| Role-based scoping (director vs teacher) | `src/db/students.ts` (`scopeClause`) |
| Encryption at rest | `src/db/database.ts`, `capacitor.config.ts` (`CapacitorSQLite.androidIsEncryption`) |
| Encryption key handling | `src/db/secureSecret.ts` — **replace before production, see file** |
| Session auto-lock | `src/context/useIdleTimeout.ts` |
| Audit log | `src/db/audit.ts`, viewer at `src/pages/AuditLog.tsx` |
| No auto-backup / trimmed permissions | `android-notes/MANIFEST_HARDENING.md` |
| Soft-delete / archive with reason | `src/db/students.ts` (`archiveStudent`, `restoreStudent`) |
| Camera-only permission (no broad storage) | `src/pages/StudentForm.tsx` (`takePhoto`) |
| CSP / no remote origins loaded | `index.html`, `capacitor.config.ts` |
