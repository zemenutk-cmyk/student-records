import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'org.yourschool.studentrecords', // change to a real reverse-DNS id before building
  appName: 'Student Records',
  webDir: 'dist',
  // No remote server / live-reload URL in the shipped config — the app must
  // only ever load its own bundled assets, never a remote origin.
  android: {
    allowMixedContent: false,
    captureInput: true,
  },
  plugins: {
    CapacitorSQLite: {
      iosDatabaseLocation: 'Library/CapacitorDatabase',
      iosIsEncryption: true,
      iosKeychainPrefix: 'student-records',
      androidIsEncryption: true,
      androidBiometric: {
        biometricAuth: false, // app has its own PIN/session layer; device biometric is an optional extra layer (see README)
        biometricTitle: 'Unlock Student Records',
      },
    },
  },
};

export default config;
