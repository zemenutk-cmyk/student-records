import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Capacitor apps are served from a local file scheme on-device, so we use
// relative asset paths and keep the dev server bindable from a real device
// on the same network during testing.
export default defineConfig({
  plugins: [react()],
  base: './',
  server: {
    host: '0.0.0.0',
    port: 5173,
  },
  build: {
    outDir: 'dist',
    sourcemap: false, // no sourcemaps in the shipped build (avoid leaking schema/logic)
  },
});
